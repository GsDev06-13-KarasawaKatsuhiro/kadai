class BlogsController < ApplicationController
  before_action:set_blog,only:[:show,:edit,:update,:destroy]

  def index
    @blogs = Blog.all
  end

  def show
    @blog = Blog.find(params[:id])
  end

  def about


  end

  def new
    @blog = Blog.new
  end

  def create
    @blog = Blog.new
    @blog.title = params[:blog][:title]
    @blog.content= params[:blog][:content]
    file = params[:blog][:image]

    if !file.nil?
      file_name = file.original_filename
      File.open("public/uploads/blog/#{file_name}","wb") {|f| f.write(file.read)}

      @blog.image = file_name
    end

    if @blog.save
      redirect_to edit_blog_path(@blog.id),notice:"新規作成完了しました！"
    else
      render :new
    end

  end

  def edit
    @blog = Blog.find(params[:id])
  end

  def update
    @blog = Blog.find(params[:id])
    @blog.title = params[:blog][:title]
    @blog.content= params[:blog][:content]
    file = params[:blog][:image]

    if !file.nil?
      file_name = file.original_filename
      File.open("public/uploads/blog/#{file_name}","wb") {|f| f.write(file.read)}

      @blog.image = file_name
    end


    if @blog.save
      redirect_to edit_blog_path(@blog.id),notice:"更新しました！"
    else
      render :new
    end
  end

  def destroy
    @blog = Blog.find(params[:id])
    if @blog.destroy
      redirect_to @blog,notice:"記事を削除しました！"
    end

  end

  # strong パラメーター
  private
  def set_blog
    @blog = Blog.find(params[:id])
  end

  def blog_params


    params.require(:blog).permit(:title,:content,:image,:image_cache)
  end


end
